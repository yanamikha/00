﻿//1. Создать класс MyMatrix, обеспечивающий представление матрицы произвольного размера с возможностью изменения 
//числа строк и столбцов.Написать программу, которая выводит на экран матрицу.
using System;

namespace Task04
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //Your code goes here
            Random random = new Random();
            MyMatrix matrix = new MyMatrix(3, 5);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                    matrix[i, j] = random.Next(1, 100);
            }
            matrix.Show();
        }
    }
    class MyMatrix
    {
        public int CountOfRows { get; set; }
        public int CountOfColumns { get; set; }
        private object [,] array;

        public MyMatrix(int row, int column)
        {
            CountOfRows = row;
            CountOfColumns = column;
            array = new object[row, column];
        }

        public object this[int a, int b]
        {
            get { return array[a, b]; }
            set { array[a, b] = value; }
        }
        public void Show()
        {
            for(int i = 0;i< CountOfRows; i++)
            {
                for (int j = 0; j < CountOfColumns; j++)
                    Console.Write(array[i, j]+ " ");
                Console.WriteLine();
            }
        } 
    }
}

 