﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Game
{
    class Base
    {
        public double Buildingslevel { get; set; } = 1;
        public int Army { get; set; }
        public Dictionary<string, int> Resources = new Dictionary<string, int> { { "People", 200 }, { "Goods", 300 }, { "Credits", 500 } };
        public int Barrack { get; set; }
        public int ResidentialModule { get; set; }
        public int Walls { get; set; }
        public int Workshop { get; set; }
        public enum Portal : Byte { buy = 15, sell = 5 }

        public string Growth()
        {
            return "Base";
            // Resources["Credits"];// 100 * ((Buildingslevel + 1) / 98.5f);
        }

    }
    class A : Base
    {
        public string Growth()
        {
            return "A";
        }
    }
}
