﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            PictureBox []pictureBox = new PictureBox[7];

            for (int i = 0; i <= 6; i++)
            {
                pictureBox[i] = new PictureBox();

                pictureBox[i].Image = Image.FromFile("C:\\Users\\User\\source\\repos\\The_Game\\tower.png");
                pictureBox[i].BackColor = Color.Transparent;
                pictureBox[i].SizeMode = PictureBoxSizeMode.Zoom;
            }
                  
            pictureBox[6].Image = Image.FromFile("C:\\Users\\User\\source\\repos\\The_Game\\Vepr_4.png");
            tableLayoutPanel1.Controls.Add(pictureBox[0], 7, 0);
            tableLayoutPanel1.Controls.Add(pictureBox[1], 0, 0);
            tableLayoutPanel1.Controls.Add(pictureBox[2], 14, 0);
            tableLayoutPanel1.Controls.Add(pictureBox[3], 0, 14);
            tableLayoutPanel1.Controls.Add(pictureBox[4], 7, 14);
            tableLayoutPanel1.Controls.Add(pictureBox[5], 14, 14);
            tableLayoutPanel1.Controls.Add(pictureBox[6], 14, 13); 


        }
    }
}
