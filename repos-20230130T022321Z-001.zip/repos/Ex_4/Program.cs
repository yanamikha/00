﻿//Даны следующие классы: Celcius и Fahrenheit.Класс Celcius представляет градусник по Цельсию, а Fahrenheit - градусник по Фаренгейту.
//Определите операторы преобразования от типа Celcius и наоборот.
//Преобразование температуры по шкале Фаренгейта (Tf) в температуру по шкале Цельсия (Tc): Tc = 5 / 9 * (Tf - 32).
//Преобразование температуры по шкале Цельсия в температуру по шкале Фаренгейта: Tf = 9 / 5 * Tc + 32.

using System;

namespace Ex_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Fahrenheit f = new Fahrenheit();
            f.Fahr = 100;
            Celcius newf = (Celcius)f;

            Celcius c = new Celcius();
            c.Cels =  56;
            Fahrenheit newc = (Fahrenheit)c;

            Console.WriteLine(newf.Cels + " " + f.Fahr);
            Console.WriteLine(newc.Fahr + " " + c.Cels);
        }
    }
    class Celcius
    {
        public int Cels { get; set; }

        public static explicit operator Celcius(Fahrenheit value)
        {
            return new Celcius { Cels = (int)Math.Round((value.Fahr - 32)* 5 / 9f) }; 
        }
    }
    class Fahrenheit
    {
        public int Fahr { get; set; }
        public static explicit operator Fahrenheit(Celcius value)
        {
            return new Fahrenheit { Fahr = (int)Math.Round(9 / 5f * value.Cels + 32) };
        }
    }
}
