﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex_06
{
    class Menu
    {
        public static void FirstLevelOfMenu()
        {

            string a = Console.ReadLine();
            switch (a)
            {
                case "1":
                    ShowSearchingMenu();
                    break;
                case "2":
                    car.Add();
                    break;
                case "3":
                    car.Edit();
                    break;
                case "4":
                    car.Delete();
                    break;
                case "0":
                    ShowMenu();
                    break;
                case '-1': return;
            }

        }

        public static void SearchingMenu()
        {
            string b = Console.ReadLine();
            switch (b)
            {
                case "1":
                    car.searchByVin();
                    break;
                case "2":
                    car.SearchByNumber();
                    break;
                case "7":
                    car.ShowAllCars();
                    break;
                case "0":
                    break;
            }
        }
        public static void ShowMenu()
        {
            Console.WriteLine(@"1 - Меню поиска.                                
                                2 - Занести в базу данные по новой машине.
                                3 - Редактирование информации о машине по VIN коду
                                4 - Удалить машину с базы по VIN коду.
                                0 - Назад
                               -1 - Выход из программы.");
        }
        public static void ShowSearchingMenu() {
            Console.WriteLine(@"1 - Поиск по VIN коду машины.
                                2 - Поиск по регистрационному номеру машины
                                7 - Отобразить список всех машин.
                                0 - назад.");

                }
    }
}