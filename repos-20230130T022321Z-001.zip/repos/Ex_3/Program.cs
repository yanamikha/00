﻿//Дан класс Clock, который хранит количество часов.В программе мы можем из числа получить количество часов и,
//    наоборот, из количество часов значение типа int. Добавьте в класс Clock оператор для неявного преобразования
//    от типа int к типу Clock, и оператор явного преобразования от типа Clock к типу int.

using System;

namespace Ex_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int t = 5;
            Clock clock = t;
            Console.WriteLine(clock.GetType() + " - clock (implisit)");
            t = (int)clock;
            Console.WriteLine(t.GetType() + " - t (explisit)");
        }
    }
    class Clock
    {
        public int AmoutOfHour { get; set; }

        public static implicit operator Clock(int a)
        {
            return new Clock { AmoutOfHour = a };
        }
        public static explicit operator int(Clock clock)
        {
            return clock.AmoutOfHour;
        }
    }
}
