﻿//Создать класс Store, содержащий закрытый массив элементов типа Article.  
//Обеспечить следующие возможности: 
//• вывод информации о товаре по номеру с помощью индекса; 
//• вывод на экран информации о товаре, название которого введено с клавиатуры, если таких товаров нет, выдать соответствующее сообщение; 
//Написать программу, вывода на экран информацию о товаре.
using System;

namespace Ex_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Store store = new Store("BigShop");

            store.AddArticle("Times", 6m);
            store.AddArticle("NewTime", 1m);
            store.AddArticle("Times", 0.2m);
            store.AddArticle("Событие", 3m);
            store.AddArticle("Комсомольская правда", 0.6m);
            store.AddArticle("Times", 6m);

            store.Show(2);
            store.Show("Times");
            store.Show("NYTimes");
        }
    }
    class Article
    {
        private string product;
        private string shop;
        private decimal cost;
        public string Product { get => product; }
     
        public Article(string product, string shop, decimal cost)
        {
            this.product = product;
            this.shop = shop;
            this.cost = cost;
        }
        public void ShowArticle()
        {
            Console.WriteLine($"The article {product} is in the shop {shop} costs {cost}");
        }
    }

    class Store
    {
        Article[] article;
        int countOfArticle;
        string name;
        public Store(string name)
        {
            article = new Article[10];
            this.name = name;
        }
        public Article this[int index]
        {
            get => article[index];
            set => article[index] = value;
        }
        public void AddArticle(string product, decimal cost)
        {
            article[countOfArticle] = new Article(product, name, cost);
            countOfArticle++;
        }
        public void Show(int index)
        {
            Console.WriteLine("The articles with index'" + index + "'");
            article[index].ShowArticle();
        }
        public void Show(string name)
        {
            Console.WriteLine("The articles with name'" + name + "':");
            bool isPrinted = false;
            for (int i = 0; i < countOfArticle; i++)
                if (article[i].Product == name)
                {
                    article[i].ShowArticle();
                    isPrinted = true;
                }
            if (isPrinted == false)
                Console.WriteLine("There aren't such article in our store...");
        }
    }
}
