﻿//Даны следующие классы:Dollar и Euro.Определите операторы преобразования от типа Dollar в Euro и наоборот.
//    Допустим, 1 евро стоит 1,14 долларов.При этом один оператор должен подразумевать явное, и один - неявное преобразование.
using System;

namespace Ex_05
{
    class Program
    {
        static void Main(string[] args)
        {
            Dollar dollar = new Dollar();
            dollar.Amount = 500;
            Euro euro = (Euro)dollar;
            Console.WriteLine(dollar.Amount + " dollars = " + euro.Amount + " euro");

            Dollar dollar1 = euro;
            Console.WriteLine(euro.Amount + " euro = " + dollar1.Amount + " dollars");
        }
    }
    class Dollar
    {
        public decimal Amount { get; set; }
        public static implicit operator Dollar(Euro euro)
        {
            return new Dollar {Amount = euro.Amount/1.14m };
        }
   
    }
    class Euro
    {
        public decimal Amount { get; set; }

        public static explicit operator Euro(Dollar dollar)
        {
            return new Euro { Amount = dollar.Amount * 1.14m };
        }
    }
}
