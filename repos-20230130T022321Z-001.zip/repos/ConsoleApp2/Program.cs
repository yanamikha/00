﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "5/6";
            int count = 0;
            string temp = "", temp2 = "";
            for (int i = 0; i < str.Length; i++)
            {
                temp = ""; temp2 = "";
                while (str[i] != '/' && i < str.Length)
                { temp += str[i].ToString(); i++; } 
                temp2 = str.Substring(i+1, str.Length - i-1);
                break;
            }
            Console.WriteLine(temp + "/" + temp2);
        }
    }
}
