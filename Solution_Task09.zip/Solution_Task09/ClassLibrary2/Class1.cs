﻿using ClassLibrary1;
using ClassLibrary3;
using System;
using System.Collections.Generic;
using System.Threading;

namespace ClassLibrary2
{
    public class Teacher:Person
    {
        List<Student> students = new List<Student>();
        public string Subject { get; set; }
        public override void Print()
        {
            Console.WriteLine("I'm a teacher");
        }
        public override string ToString()
        {
            return base.ToString();
        }
        public static Teacher RandomTeacher()
        {
            Random random = new Random();
            Thread.Sleep(11);
          
                CreateName();
            Teacher teacher = new Teacher { Name = name[random.Next(countOfRandomPeople - 1)] };
            return teacher;
        }
        public static new string GetType()
        {
            return Teacher.GetType();
        }
        public override Person Clone(object obj)
        {
            if (obj == null) return null;
            Teacher clone = new Teacher();
            clone = obj as Teacher;
            clone.Subject = (obj as Teacher).Subject;
            clone.Name =  (obj as Teacher).Name;           
            return clone;
        }
    }
}
