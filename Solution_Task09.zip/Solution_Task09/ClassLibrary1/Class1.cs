﻿using System;
using System.Threading;

namespace ClassLibrary1
{
    public class Person
    {
        public static string [] name;
        protected string Name { get; set; }
        private static int countOfPeople;
        protected static int countOfRandomPeople;
        public Person()
        { 
        }
        public Person(int countOfPeople)
        {
            //Person.countOfPeople = countOfPeople;
            //people = new Person[Person.countOfPeople];
        }
        protected static void CreateName()
        {
            countOfRandomPeople = 5;
            name = new string [countOfRandomPeople];
            name[0] = "Vova";
            name[1] = "Nina";
            name[2] = "Anna";
            name[3] = "Igor";
            name[4] = "Leonid";
        }

        public virtual void Print()
        {
            Console.WriteLine("I'm jast a human");
        }
       
        public override string ToString()
        {
            return base.ToString();
        }
        public static Person RandomPerson()
        {
            Random random = new Random();
            CreateName();
            int index = random.Next(countOfRandomPeople - 1);
            Person person = new Person { Name = name[index] };
            return person;
        }
        public virtual Person Clone(object obj)
        {
            if (obj == null) return null;
            Person clone = new Person();
            clone.Name = (obj as Person).Name;
            clone = obj as Person;
            return clone;
        }
    }
}
