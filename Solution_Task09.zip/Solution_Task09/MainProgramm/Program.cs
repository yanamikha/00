﻿using ClassLibrary1;
using ClassLibrary2;
using ClassLibrary3;
using ClassLibrary4;
using System;

namespace MainProgramm
{
    class Program
    {
        static void Main(string[] args)
        {
            Person[] people = new Person[10];

            people[0] = Teacher.RandomTeacher();
            people[1] = Teacher.RandomTeacher();
            people[2] = Teacher.RandomTeacher();
            people[3] = Teacher.RandomTeacher();
            people[4] = Person.RandomPerson();
            people[5] = Person.RandomPerson();
            people[6] = Person.RandomPerson();
            people[7] = StudentWithAdvisor.RandomStudent();
            people[8] = StudentWithAdvisor.RandomStudent();
            people[9] = StudentWithAdvisor.RandomStudent();

            int countOfStudent = 0, countOfPerson = 0, countOfTeacher = 0;

            for (int i = 0; i < people.Length; i++)
            {
                if (people[i].GetType() == typeof(Teacher))
                    countOfTeacher++;
                else if (people[i].GetType() == typeof(Student))
                {
                    countOfStudent++;
                    Student student = people[i] as Student;
                    student.NextCourse();
                }
                else if (people[i].GetType() == typeof(Person))
                    countOfPerson++;
            }
            people[5].Clone(people[6]);
            Console.WriteLine($"Person: {countOfPerson}, Student: {countOfStudent}, Teacher:{countOfTeacher}");

            for (int i = 0; i < people.Length; i++)
            {
                Console.WriteLine($"Person {i+1}: {people[i]}.GetType()");
                Type type = null;
                while (!(type.ToString().Equals("System.Object")))
                {
                    Person temp = people[i].GetType;
                    type = temp.GetType().BaseType;
                }
        }
    }
}
