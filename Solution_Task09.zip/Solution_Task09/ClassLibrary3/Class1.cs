﻿using System;
using System.Threading;
using ClassLibrary1;

namespace ClassLibrary3
{
    public class Student : Person
    {
        
        public string Group { get; set; }
        public int Course { get; set; } = 1;
        public override void Print()
        {
            Console.WriteLine("I'm a student");
        }
        public override string ToString()
        {
            return base.ToString();
        }
        public void NextCourse()
        {
            Course = Course < 6 ? Course + 1 : Course;
        }
        public static Student RandomStudent()
        {
            Random random = new Random();
            Thread.Sleep(11);
         
                CreateName();
            Student student = new Student { Name = name[random.Next(countOfRandomPeople - 1)] };
            return student;
        }
        public override Person Clone(object obj)
        {
            if (obj == null) return null;

            Student clone = new Student();
            clone = obj as Student;
            clone.Name = (obj as Student).Name;
            clone.Group = (obj as Student).Group;
            clone.Course = (obj as Student).Course;

            return clone;
        }
        public new string GetType()
        {
            return this.GetType();
        }
    }
}
