﻿using ClassLibrary2;
using ClassLibrary3;
using System;

namespace ClassLibrary4
{
    public class StudentWithAdvisor : Student
    {
        Teacher teacher = new Teacher();
    }
}
